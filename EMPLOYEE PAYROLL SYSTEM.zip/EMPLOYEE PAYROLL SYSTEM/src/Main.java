import java.util.ArrayList;

// Abstract class representing a generic Employee
abstract class Employee {
    private String name;  // Employee name (private for encapsulation)
    private int id;       // Employee ID (private)

    // Constructor to initialize name and ID
    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Getter for ID
    public int getId() {
        return id;
    }

    // Abstract method to calculate salary (implemented in subclasses)
    abstract double calculateSalary();

    // Overriding toString() method to print employee details
    @Override
    public String toString() {
        return "Employee [Name = " + name + ", Salary = " + calculateSalary() + "]";
    }
}

// Full-time employee class extending Employee
class FullTimeEmployee extends Employee {
    private double monthlySalary;

    // Constructor to initialize full-time employee details
    public FullTimeEmployee(String name, int id, double monthlySalary) {
        super(name, id);  // Call to parent constructor
        this.monthlySalary = monthlySalary;
    }

    // Calculate salary for full-time employee
    @Override
    public double calculateSalary() {
        return monthlySalary;
    }
}

// Part-time employee class extending Employee
class PartTimeEmployee extends Employee {
    private int hoursWorked;
    private double hourlyRate;

    // Constructor to initialize part-time employee details
    public PartTimeEmployee(String name, int id, int hoursWorked, double hourlyRate) {
        super(name, id);  // Call to parent constructor
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    // Calculate salary for part-time employee
    @Override
    public double calculateSalary() {
        return hourlyRate * hoursWorked;
    }
}

// PayrollSystem class to manage employee operations
class PayrollSystem {
    private ArrayList<Employee> employeeList;  // List to store employees

    // Constructor initializes the employee list
    public PayrollSystem() {
        employeeList = new ArrayList<>();
    }

    // Method to add an employee to the list
    public void addEmployee(Employee employee) {
        employeeList.add(employee);
    }

    // Method to remove an employee by ID
    public void removeEmployee(int id) {
        Employee employeeToRemove = null;

        // Search for the employee with matching ID
        for (Employee employee : employeeList) {
            if (employee.getId() == id) {
                employeeToRemove = employee;
                break;
            }
        }

        // Remove the employee if found
        if (employeeToRemove != null) {
            employeeList.remove(employeeToRemove);
            System.out.println("Employee with ID " + id + " removed.");
        } else {
            System.out.println("Employee with ID " + id + " not found.");
        }
    }

    // Method to display all employee details
    public void displayEmployee() {
        for (Employee employee : employeeList) {
            System.out.println(employee);
        }
    }
}

// Main class to run the program
public class Main {
    public static void main(String[] args) {

        // Creating PayrollSystem object
        PayrollSystem payrollSystem = new PayrollSystem();

        // Creating full-time and part-time employees
        FullTimeEmployee emp1 = new FullTimeEmployee("Vikash", 1, 70000.00);
        PartTimeEmployee emp2 = new PartTimeEmployee("Jay", 2, 40, 100);

        // Adding employees to the payroll system
        payrollSystem.addEmployee(emp1);
        payrollSystem.addEmployee(emp2);

        // Displaying all employees
        System.out.println("Initial Employee Details:");
        payrollSystem.displayEmployee();

        // Removing employee with ID 1
        System.out.println("\nRemoving Employee with ID 1...");
        payrollSystem.removeEmployee(1);

        // Displaying remaining employees
        System.out.println("\nRemaining Employee Details:");
        payrollSystem.displayEmployee();
    }
}
